package com.hand.ssm.mapper;

import java.util.List;

import com.hand.ssm.dto.Customer;

public interface CustomerMapper {
	public Customer select(Customer customer);

	public void addCustomer(Customer customer);

	public int findLinkQueryCount(String firstName);

	public List<Customer> likeQueryByName(String firstName, int beginIndex,
			int everyPage);

	public void setKey(int value);

	public void deleteCustomer(Customer customer);

	public Customer findOneCustomer(Customer customer);

	public void updateCustomer(Customer customer);
	
}
