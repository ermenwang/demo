package com.hand.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hand.ssm.dto.Customer;
import com.hand.ssm.dto.Film;
import com.hand.ssm.mapper.CustomerMapper;
import com.hand.ssm.service.CustomerService;
import com.hand.ssm.util.Page;
import com.hand.ssm.util.PageResult;
import com.hand.ssm.util.PageUtil;




@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerMapper customerMapper;
	
	
	public Customer select(Customer customer) {
		Customer custUser=customerMapper.select(customer);
		return custUser;
	}


	public void addCustomer(Customer customer) {
		customerMapper.addCustomer(customer);
	}


	public PageResult findCustomerByLike(String firstName, Page page) {
		page = PageUtil.createPage(page.getEveryPage(),
				customerMapper.findLinkQueryCount(firstName),page.getCurrentPage());
		List<Customer> list = customerMapper.likeQueryByName(firstName, page.getBeginIndex(),page.getEveryPage());
		PageResult result = new PageResult(page,list);
		return result;
	}


	public void deleteCustomer(Customer customer) {
		customerMapper.setKey(0);
		customerMapper.deleteCustomer(customer);
		customerMapper.setKey(1);
		
	}


	public Customer queryOneFilm(Customer customer) {
		return customerMapper.findOneCustomer(customer);
		
	}


	public void updateCustomer(Customer customer) {
		System.out.println(customer.getLastName());
		customerMapper.updateCustomer(customer);
	}

}
