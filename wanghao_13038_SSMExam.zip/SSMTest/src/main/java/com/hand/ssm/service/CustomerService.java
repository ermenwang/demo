package com.hand.ssm.service;

import java.util.List;

import com.hand.ssm.dto.Customer;
import com.hand.ssm.util.Page;
import com.hand.ssm.util.PageResult;

public interface CustomerService {
	public Customer select(Customer customer);

	public void addCustomer(Customer customer);

	public PageResult findCustomerByLike(String firstName, Page page);

	public void deleteCustomer(Customer customer);

	public Customer queryOneFilm(Customer customer);

	public void updateCustomer(Customer customer);

}
