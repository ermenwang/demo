package com.hand.ssm.mapper;

import java.util.List;

import com.hand.ssm.dto.Film;
import com.hand.ssm.util.Page;

public interface FilmMapper {
    public List<Film> select(Film film);
    
    public int insertFilm(Film film);
    
    public int findFilmCount();
    
    public Film findOneFilm(Film flim);
    
    public List<Film> findFilmByPage(Page page);
    
    public void updateFilm(Film film);
    
    public void deleteFilm(Film film);
    
    public void setKey(int value);

	public int findLinkQueryCount(String title);

	public List<Film> likeQueryByTitle(String title, int beginIndex, int everyPage);
}
