package com.hand.ssm.service;

import java.util.List;

import com.hand.ssm.dto.Film;
import com.hand.ssm.util.Page;
import com.hand.ssm.util.PageResult;



public interface FilmService {
    public List<Film> select(Film film);
    
	public PageResult queryFilmByPage(Page page);
	
	public Film queryOneFilm(Film film);
	
	public void updateFilm(Film film);
	
	public void deleteFilm(Film film);

	public int addFilm(Film film);

	public PageResult findFilmByLike(String title, Page page);

}
