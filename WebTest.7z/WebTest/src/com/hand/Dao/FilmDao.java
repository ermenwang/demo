package com.hand.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hand.Bean.Film_bean;
import com.hand.Jbcon.JdbcUtil;


public class FilmDao {
	Connection conn = JdbcUtil.getConnection();
	PreparedStatement pstmt = null;
	ResultSet rs=null;
	public List<Film_bean> getAllUser() {
		String findSQL = "select film_id,title,description,`name` from film , language where film.language_id=`language`.language_id ORDER BY film_id";
		List<Film_bean> userlist = new ArrayList<Film_bean>();
		try {
			pstmt = conn.prepareStatement(findSQL);		//���Ԥ�������󲢸�ֵ
			rs = pstmt.executeQuery();				//ִ�в�ѯ
			while(rs.next()) {
				Film_bean film = new Film_bean();
				film.setFilm_id(rs.getString(1));
				film.setTitle(rs.getString(2));				
				film.setDescription(rs.getString(3));
				film.setLanguage(rs.getString(4));
				userlist.add(film);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);							//�ر����Ӷ���
		}
		return userlist;
	}
	public boolean deleteFilm(String film_id){
		String sql="delete from film where film_id=?";
		boolean result=false;
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, film_id);
			rs=pstmt.executeQuery();
			result=true;
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);
		}
		return result;
	}
	public Film_bean getFilm(String film_id){
		String sql="select film_id,title,description,`name` from film , language where film.language_id=`language`.language_id and film.film_id=?";
		Film_bean film=new Film_bean();
		try{
			System.out.println(film_id);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, film_id);
			System.out.println(pstmt);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				film.setFilm_id(rs.getString(1));
				film.setTitle(rs.getString(2));				
				film.setDescription(rs.getString(3));
				film.setLanguage(rs.getString(4));
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);
		}
		return film;
	}
	public String getLanguage_id(String language_name){
		String sql ="select language_id from language where name=?";
		String language_id=null;
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, language_name);
			rs=pstmt.executeQuery();
			if (rs.next())
				language_id=rs.getString(1);
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);
		}
		return language_id;
	}
	public boolean updatedFilm(Film_bean film){
		String sql = "update film set title=?,description=?,language_id=? where film_id=?";
		boolean result=false;
		Connection conn = JdbcUtil.getConnection();
		PreparedStatement pstmt = null;
		String language_id=getLanguage_id(film.getLanguage());
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, film.getTitle());
			pstmt.setString(2, film.getDescription());
			pstmt.setString(3, language_id);
			pstmt.setString(4, film.getFilm_id());
			result=pstmt.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);
		}
		return result;
	}
	public boolean addFilm(Film_bean film){
		String sql = "insert into film (film_id,title,description,language_id) values (?,?,?,?)";
		boolean result=false;
		Connection conn = JdbcUtil.getConnection();
		PreparedStatement pstmt = null;
		String language_id=getLanguage_id(film.getLanguage());
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(2, film.getTitle());
			pstmt.setString(3, film.getDescription());
			pstmt.setString(4, language_id);
			pstmt.setString(1, film.getFilm_id());
			result=pstmt.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);
		}
		return result;
	}
	public boolean LoginCheck(String first_name){
		String sql = "select * from actor where first_name=?";
		boolean result=false;
		try{
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, first_name);
			rs=pstmt.executeQuery();
			result=rs.next() ? true : false;
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			JdbcUtil.close(rs);								//�رս��������
			JdbcUtil.close(pstmt);							//�ر�Ԥ��������
			JdbcUtil.close(conn);
		}
		return result;
	}
}
