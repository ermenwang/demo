package com.hand.factory;

import com.hand.Dao.FilmDao;

public class FilmDaoFactory {
	public static FilmDao getUserDaoInstance(){
		return new FilmDao();
	}
}
