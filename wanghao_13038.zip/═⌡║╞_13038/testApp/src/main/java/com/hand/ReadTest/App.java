package com.hand.ReadTest;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
/**
 * Hello world!
 *
 */
public class App 
{
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String address = "http://www.madore.org/~david/math/padics.pdf";
		String fileName="padics.pdf";
		URL url=new URL(address);
		int count;
		FileOutputStream filestr=new FileOutputStream(fileName);
		URLConnection connect=url.openConnection();
		DataInputStream in=new DataInputStream(connect.getInputStream());
		DataOutputStream out= new DataOutputStream(filestr);
		byte[] buff = new byte[1024];
		while ((count = in.read(buff)) > 0)
			out.write(buff,0,count);
		out.close();
		in.close();
	}
}
