package com.hand.ssm.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.hand.ssm.dto.Film;
import com.hand.ssm.service.FilmService;
import com.hand.ssm.util.Page;
import com.hand.ssm.util.PageResult;

@Controller
public class FilmController {
     @Autowired
	private FilmService filmService;
     
     
    
    @RequestMapping("/kaishi")
    public String index(Map<String, Object> map){   	
        return"login";
    }
    
   
    @RequestMapping("/selectFilm")
    public String select(Map<String, Object> map){
    	Film film=new Film();  	
        int page=1;
    	film.setCursor((page-1)*10);
    	map.put("list", filmService.select(film));
        return"show";
   
    }
    

    @RequestMapping("/tianjia")
    public String tianjia(){
        return"tianjia";
    }
    
    
    @RequestMapping("/queryFilmByPage")
    public String selectFilmByPage(HttpServletRequest request,HttpServletResponse response){
    	int currentPage=Integer.valueOf(request.getParameter("currentPage"));
		Page page = new Page();
		page.setEveryPage(10);//每页显示10条记录
		page.setCurrentPage(currentPage);//设置当前页
		PageResult pageResult = filmService.queryFilmByPage(page);
		List<Film> subjects = pageResult.getList();//获得试题记录
		page = pageResult.getPage();//获得分页信息
		request.setAttribute("listFilm", subjects);
		request.setAttribute("page", page);
		return "filmManage";
    }
    
    
    @RequestMapping("/queryOneFilm")
    public String queryOneFilm(HttpServletRequest request,HttpServletResponse response){
    	Film film=new Film();
    	Integer filmId=Integer.valueOf(request.getParameter("filmId"));
    	film.setFilmId(filmId);
    	film=filmService.queryOneFilm(film);
    	request.setAttribute("film", film);
		return "filmShow";
    }
    
    @RequestMapping("/updateFilmBefore")
    public String updateFilmBefore(HttpServletRequest request,HttpServletResponse response){
    	Film film=new Film();
    	Integer filmId=Integer.valueOf(request.getParameter("filmId"));
    	film.setFilmId(filmId);
    	film=filmService.queryOneFilm(film);
    	request.setAttribute("film", film);
		return "filmUpdate";
    }
    
    @RequestMapping("/updateFilm")
    public String updateFilm(HttpServletRequest request,HttpServletResponse response){
    	Film film=new Film();
    	Integer filmId=Integer.valueOf(request.getParameter("filmId"));
    	String title=request.getParameter("title");
    	String description=request.getParameter("description");
    	String releaseYear=request.getParameter("releaseYear");
    	releaseYear="2006";
    	Integer languageId=Integer.valueOf(request.getParameter("languageId"));
    	Integer rentalDuration=Integer.valueOf(request.getParameter("rentalDuration"));
    	Double rentalRate=Double.valueOf(request.getParameter("rentalRate"));
    	Integer length=Integer.valueOf(request.getParameter("length"));
    	String specialFeatures=request.getParameter("specialFeatures");
    	String lastUpdate=request.getParameter("lastUpdate");
    	film.setFilmId(filmId);
    	film.setTitle(title);
    	film.setDescription(description);
    	film.setReleaseYear(releaseYear);
    	film.setLanguageId(languageId);
    	film.setRentalDuration(rentalDuration);
    	film.setRentalRate(rentalRate);
    	film.setLength(length);
    	film.setSpecialFeatures(specialFeatures);
    	film.setLastUpdate(lastUpdate);
    	filmService.updateFilm(film);
    	return"redirect:/queryFilmByPage?currentPage=0";
    }
    
    @RequestMapping("/deleteFilm")
    public String deleteFilm(HttpServletRequest request,HttpServletResponse response){
    	Film film=new Film();
    	Integer filmId=Integer.valueOf(request.getParameter("filmId"));
    	film.setFilmId(filmId);
    	filmService.deleteFilm(film);
    	return"redirect:/queryFilmByPage?currentPage=0";
    }
    
    
    @RequestMapping("/addFilm")
    public String addFilm(HttpServletRequest request,HttpServletResponse response){
    	Film film=new Film();
    	//Integer filmId=Integer.valueOf(request.getParameter("filmId"));
    	String title=request.getParameter("title");
    	String description=request.getParameter("description");
    	String releaseYear=request.getParameter("releaseYear");
    	releaseYear="2006";
    	Integer languageId=Integer.valueOf(request.getParameter("languageId"));
    	Integer rentalDuration=Integer.valueOf(request.getParameter("rentalDuration"));
    	Double rentalRate=Double.valueOf(request.getParameter("rentalRate"));
    	Integer length=Integer.valueOf(request.getParameter("length"));
    	String specialFeatures=request.getParameter("specialFeatures");
    	String lastUpdate=request.getParameter("lastUpdate");
    	//film.setFilmId(filmId);
    	film.setTitle(title);
    	film.setDescription(description);
    	film.setReleaseYear(releaseYear);
    	film.setLanguageId(languageId);
    	film.setOriginalLanguageId(1);
    	film.setRentalDuration(rentalDuration);
    	film.setRentalRate(rentalRate);
    	film.setReplacementCost(11);
    	film.setLength(length);
    	film.setSpecialFeatures(specialFeatures);
    	film.setLastUpdate(lastUpdate);
    	int i=filmService.addFilm(film);
    	return"redirect:/queryFilmByPage?currentPage=0";
    }
    
    @RequestMapping("/filmLikeQuery")
    public String filmLikeQuery(HttpServletRequest request,HttpServletResponse response){
    	String title=request.getParameter("filmTitle");
    	title=title.toUpperCase();
    	int currentPage;
    	if (request.getParameter("currentPage")==null)
    		currentPage=0;
    	else 
    		 currentPage= Integer.valueOf(request.getParameter("currentPage"));
		Page page = new Page();
		page.setEveryPage(10);
		page.setCurrentPage(currentPage);
		PageResult pageResult = filmService.findFilmByLike(title, page);
		List<Film> filmList = pageResult.getList();
		List<Film> newfilm = new ArrayList<Film>();
		for(Film film : filmList) {
			String newTitle = film.getTitle().replaceAll(title,
						"<font color='red'>" + title + "</font>");
			film.setTitle(newTitle);
			newfilm.add(film);
		}	
		page = pageResult.getPage();
		request.setAttribute("listFilm", newfilm);
		request.setAttribute("page", page);
		request.setAttribute("title", title);
		return "filmManage";
    }
    
}