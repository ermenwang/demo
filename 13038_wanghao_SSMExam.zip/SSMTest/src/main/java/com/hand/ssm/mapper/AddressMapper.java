package com.hand.ssm.mapper;

import java.util.List;

import com.hand.ssm.dto.Address;

public interface AddressMapper {
	public List<Address> findAddress();
}
