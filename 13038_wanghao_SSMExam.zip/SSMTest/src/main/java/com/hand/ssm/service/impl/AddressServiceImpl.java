package com.hand.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hand.ssm.dto.Address;
import com.hand.ssm.mapper.AddressMapper;


@Service
@Transactional
public class AddressServiceImpl implements com.hand.ssm.service.AddressService {

	@Autowired
	private AddressMapper addressMapper;
	
	
	
	public List<Address> findAddress() {
		System.out.println("aaaaaaaaaaaaaaaaaaaa"+addressMapper.findAddress().size());
		return addressMapper.findAddress();
	}

}
