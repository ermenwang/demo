package com.hand.ssm.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hand.ssm.dto.Address;
import com.hand.ssm.dto.Customer;
import com.hand.ssm.dto.Film;
import com.hand.ssm.service.AddressService;
import com.hand.ssm.service.CustomerService;
import com.hand.ssm.service.FilmService;
import com.hand.ssm.util.Page;
import com.hand.ssm.util.PageResult;

@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private AddressService addressService;

	/*
	 * @RequestMapping("/kaishi") public String index(Map<String, Object> map){
	 * return"login"; }
	 */

	@RequestMapping("/login")
	public String login(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("username");
		String password = request.getParameter("password");
		Customer customer = new Customer();
		customer.setFirstName(name);
		customer.setLastName(password);
		Customer cust = customerService.select(customer);
		if (cust == null)
			return "redirect:/views/login.jsp";
		else {
			request.getSession().setAttribute("logon", cust);
			return "redirect:/views/index.html";
		}

	}

	@RequestMapping("/addCutomerBefore")
	public String addCutomerBefore(HttpServletRequest request,
			HttpServletResponse response) {
		List<Address> listAddress = addressService.findAddress();
		System.out.println(listAddress.size());
		request.setAttribute("listAddress", listAddress);
		return "customerAdd";
	}

	@RequestMapping("/addCutomer")
	public void addCutomer(HttpServletRequest request,
			HttpServletResponse response) {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");
		Integer addressId = Integer.valueOf(request.getParameter("addressId"));
		Customer customer = new Customer();
		customer.setStoreId(1);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setEmail(email);
		customer.setAddressId(addressId);
		customer.setActive(1);
		customer.setCreateDate("2006-02-14 22:04:36");
		customer.setLastUpdate("2017-03-25 19:30:31");
		customerService.addCustomer(customer);
    	try {
			response.getWriter().println("<script>window.open('views/index.jsp','_parent');</script>");
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@RequestMapping("/queryCustomerByPage")
	public String queryCustomerByPage(HttpServletRequest request,
			HttpServletResponse response) {
		String firstName = request.getParameter("firstName");
		int currentPage;
		if (request.getParameter("currentPage") == null)
			currentPage = 0;
		else
			currentPage = Integer.valueOf(request.getParameter("currentPage"));
		System.out.println(request.getParameter("currentPage"));
		Page page = new Page();
		page.setEveryPage(10);
		page.setCurrentPage(currentPage);
		PageResult pageResult = customerService.findCustomerByLike(firstName,
				page);
		List<Customer> customerList = pageResult.getList();
		List<Customer> newcustomer = new ArrayList<Customer>();
		for (Customer customer : customerList) {
			System.out.println(customer.getFirstName()
					+ customer.getCreateDate());
			String newName = customer.getFirstName().replaceAll(firstName,
					"<font color='red'>" + firstName + "</font>");
			customer.setFirstName(newName);
			newcustomer.add(customer);
		}
		page = pageResult.getPage();
		request.setAttribute("listcustomer", newcustomer);
		request.setAttribute("page", page);
		request.setAttribute("name", firstName);
		return "customerManage";
	}

	@RequestMapping("/deleteCustomer")
	public String deleteCustomer(HttpServletRequest request,
			HttpServletResponse response) {
		Customer customer = new Customer();
		Integer customerId = Integer
				.valueOf(request.getParameter("customerId"));
		customer.setCustomerId(customerId);
		customerService.deleteCustomer(customer);
		return "customerQuery";
	}

	@RequestMapping("/updateCustomerBefore")
	public String updateFilmBefore(HttpServletRequest request,
			HttpServletResponse response) {
		Customer customer = new Customer();
		Integer customerId = Integer
				.valueOf(request.getParameter("customerId"));
		customer.setCustomerId(customerId);
		customer = customerService.queryOneFilm(customer);
		List<Address> listAddress = addressService.findAddress();
		request.setAttribute("customer", customer);
		request.setAttribute("listAddress", listAddress);
		return "customerUpdate";
	}

	@RequestMapping("/updateCustomer")
	public String updateFilm(HttpServletRequest request,
			HttpServletResponse response) {
		Integer customerId = Integer
				.valueOf(request.getParameter("customerId"));
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String email = request.getParameter("email");
		Integer addressId = Integer.valueOf(request.getParameter("addressId"));
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		customer.setStoreId(1);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setEmail(email);
		customer.setAddressId(addressId);
		customer.setActive(1);
		customer.setCreateDate("2006-02-14 22:04:36");
		customer.setLastUpdate("2017-03-25 19:30:31");
		customerService.updateCustomer(customer);
		return "customerQuery";
	}

	@RequestMapping("/exitLogin")
    public void exitLogin(HttpServletRequest request,HttpServletResponse response){
    	request.getSession().removeAttribute("logon");
    	try {
			response.getWriter().println("<script>window.open('views/login.jsp','_parent');</script>");
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}