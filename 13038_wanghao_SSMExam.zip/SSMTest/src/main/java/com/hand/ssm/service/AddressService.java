package com.hand.ssm.service;

import java.util.List;

import com.hand.ssm.dto.Address;

public interface AddressService {
	public List<Address> findAddress();
}
