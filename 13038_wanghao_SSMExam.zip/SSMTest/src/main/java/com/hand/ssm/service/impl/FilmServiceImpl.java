package com.hand.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hand.ssm.dto.Film;
import com.hand.ssm.mapper.FilmMapper;
import com.hand.ssm.service.FilmService;
import com.hand.ssm.util.Page;
import com.hand.ssm.util.PageResult;
import com.hand.ssm.util.PageUtil;







@Service
@Transactional
public class FilmServiceImpl implements FilmService {
	
	 @Autowired
	 private FilmMapper filmMapper;
	 
	


	public List<Film> select(Film film) {
		List<Film> filmList=filmMapper.select(film);
		return filmList;
	}


	public int addFilm(Film film) {
		return filmMapper.insertFilm(film);
	}
	
	
	
	public PageResult queryFilmByPage(Page page) {
		page = PageUtil.createPage(page.getEveryPage(),
				filmMapper.findFilmCount(),page.getCurrentPage());//根据总记录数创建分页信息
		List<Film> list = filmMapper.findFilmByPage(page);//通过分页信息取得试题
		PageResult result = new PageResult(page,list);//封装分页信息和记录信息，返回给调用处
		return result;
	}
	
	public Film queryOneFilm(Film film){
		return filmMapper.findOneFilm(film);
	}
	
	public void updateFilm(Film film){
		filmMapper.updateFilm(film);
	}

	public void deleteFilm(Film film){
		filmMapper.setKey(0);
		filmMapper.deleteFilm(film);
		filmMapper.setKey(1);
	}
	
	public PageResult findFilmByLike(String title, Page page){
		page = PageUtil.createPage(page.getEveryPage(),
				filmMapper.findLinkQueryCount(title),page.getCurrentPage());
		List<Film> list = filmMapper.likeQueryByTitle(title, page.getBeginIndex(),page.getEveryPage());
		PageResult result = new PageResult(page,list);
		return result;
	}
}
